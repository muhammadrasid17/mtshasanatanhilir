const books = [
    { judul: "Matematika Kelas 9", penulis: "Budi Santoso", stok: 3 },
    { judul: "IPA Terpadu", penulis: "Siti Aminah", stok: 5 },
    { judul: "Bahasa Indonesia", penulis: "Andi Wijaya", stok: 2 }
];

const loanRecord = [];

function loadBooks() {
    const bookList = document.getElementById("bookList");
    const selectBook = document.getElementById("judulBuku");
    bookList.innerHTML = "";
    selectBook.innerHTML = "";

    books.forEach(book => {
        bookList.innerHTML += `
            <tr>
                <td>${book.judul}</td>
                <td>${book.penulis}</td>
                <td>${book.stok}</td>
            </tr>
        `;
        if (book.stok > 0) {
            selectBook.innerHTML += `<option value="${book.judul}">${book.judul}</option>`;
        }
    });
}

function loadLoans() {
    const recordTable = document.getElementById("loanRecord");
    recordTable.innerHTML = "";
    loanRecord.forEach(record => {
        recordTable.innerHTML += `
            <tr>
                <td>${record.nama}</td>
                <td>${record.judul}</td>
                <td>${record.tanggal}</td>
            </tr>
        `;
    });
}

document.getElementById("loanForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const nama = document.getElementById("nama").value;
    const judul = document.getElementById("judulBuku").value;
    const tanggal = document.getElementById("tglPinjam").value;

    const book = books.find(b => b.judul === judul);
    if (book && book.stok > 0) {
        book.stok -= 1;
        loanRecord.push({ nama, judul, tanggal });
        loadBooks();
        loadLoans();
        this.reset();
    } else {
        alert("Buku tidak tersedia.");
    }
});

loadBooks();
loadLoans();
